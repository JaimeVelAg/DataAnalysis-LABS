# Data Wrangling

# What is the purpose of Data Wrangling?
#Data Wrangling is the process of converting data from the initial format to a format that may be better for analysis.

#Dataset: https://archive.ics.uci.edu/ml/machine-learning-databases/autos/imports-85.data
import pandas as pd
import matplotlib.pylab as plt
import numpy as np
import matplotlib as plt
from matplotlib import pyplot
filename = "https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/IBMDeveloperSkillsNetwork-DA0101EN-SkillsNetwork/labs/Data%20files/auto.csv"

headers = ["symboling","normalized-losses","make","fuel-type","aspiration", "num-of-doors","body-style",
         "drive-wheels","engine-location","wheel-base", "length","width","height","curb-weight","engine-type",
         "num-of-cylinders", "engine-size","fuel-system","bore","stroke","compression-ratio","horsepower",
         "peak-rpm","city-mpg","highway-mpg","price"]

df = pd.read_csv(filename, names = headers)
#### print(df.head())

#As we can see, several question marks appeared in the dataframe; those are missing values which may hinder our further analysis.
#Steps for working with missing data:
#   dentify missing data
#    deal with missing data
#    correct data format

###### Convert "?" to NaN
df.replace("?", np.nan, inplace = True)
#print(df.head(5))


#Evaluating for Missing Data
#The missing values are converted to default. We use the following
#functions to identify these missing values. There are two methods to detect missing data:
#.isnull()
#.notnull()
#"True" stands for missing value, while "False" stands for not missing value.
missing_data = df.isnull()
#print(missing_data.head(5))


#Count missing values in each column
#for column in missing_data.columns.values.tolist():
    #print(column)
    #print (missing_data[column].value_counts())
    #print("")

#Based on the summary above, each column has 205 rows of data, seven columns containing missing data:
#"normalized-losses": 41 missing data
#"num-of-doors": 2 missing data
#"bore": 4 missing data
#"stroke" : 4 missing data
#"horsepower": 2 missing data
#"peak-rpm": 2 missing data
#"price": 4 missing data




#Deal with missing data
#How to deal with missing data?
#drop data
#a. drop the whole row: "price": 4 missing data, simply delete the whole row
#b. drop the whole column
#replace data
#a. replace it by mean: "normalized-losses": 41 missing data, replace them with mean", "stroke": 4 missing data, replace them with mean...
#b. replace it by frequency: num-of-doors": 2 missing data, replace them with "four"
#c. replace it based on other functions

############# Calculate the average of the column ########
avg_norm_loss = df["normalized-losses"].astype("float").mean(axis=0)
#print("Average of normalized-losses:", avg_norm_loss)

#Replace "NaN" by mean value in "normalized-losses" column
df["normalized-losses"].replace(np.nan, avg_norm_loss, inplace=True)

#Calculate the mean value for 'bore' column
avg_bore=df['bore'].astype('float').mean(axis=0)
#print("Average of bore:", avg_bore)

#Replace NaN by mean value
df["bore"].replace(np.nan, avg_bore, inplace=True)


#Question #1: According to the example above, replace NaN in "stroke" column by mean
#Calculate the mean vaule for "stroke" column
avg_stroke = df["stroke"].astype("float").mean(axis = 0)
#print("Average of stroke:", avg_stroke)

# replace NaN by mean value in "stroke" column
df["stroke"].replace(np.nan, avg_stroke, inplace = True)
#print(df.head(10))

#To see which values are present in a particular column, we can use the ".value_counts()" method:
#print(df['normalized-losses'].value_counts())

#We can see that four doors are the most common type. We can also use the ".idxmax()"
#method to calculate for us the most common type automatically:
#print(df['normalized-losses'].value_counts().idxmax())

#Finally, let's drop all rows that do not have price data:
# simply drop whole row with NaN in "price" column
df.dropna(subset=["price"], axis=0, inplace=True)

# reset index, because we droped two rows
df.reset_index(drop=True, inplace=True)
df.head()
###################### Good! Now, we obtain the dataset with no missing values. ##################
#The last step in data cleaning is checking and making sure that all data is in the correct format (int, float, text or other).
#In Pandas, we use
#.dtype() to check the data type
#.astype() to change the data type

#Lets list the data types for each column
#print(df.dtypes)

#As we can see above, some columns are not of the correct data type. Numerical
#variables should have type 'float' or 'int', and variables with strings such as categories should have type 'object'.
#For example, 'bore' and 'stroke' variables are numerical values that describe the engines, so we should expect them to
#be of the type 'float' or 'int'; however, they are shown as type 'object'. We have to convert data types into a proper
#format for each column using the "astype()" method.

######################################## Convert data types to proper format ##########################
df[["bore", "stroke"]] = df[["bore", "stroke"]].astype("float")
df[["normalized-losses"]] = df[["normalized-losses"]].astype("int")
df[["price"]] = df[["price"]].astype("float")
df[["peak-rpm"]] = df[["peak-rpm"]].astype("float")
#print(df.dtypes)

#Now, we finally obtain the cleaned dataset with no missing values and all data in its proper format.

################################ Data Normalization #################
df['height'] = df['height']/df['height'].max()
df['length'] = df['length']/df['length'].max()
df['width'] = df['width']/df['width'].max()
# show the scaled columns
#print(df[["length","width","height"]].head())


##################################### Binning ############################
df.dropna(subset=["horsepower"], axis=0, inplace=True)
df["horsepower"]=df["horsepower"].astype(int, copy=True)

#################################### Lets plot the histogram of horspower, to see what the distribution of horsepower looks like. #

#plt.pyplot.hist(df["horsepower"])
# set x/y labels and plot title
#plt.pyplot.xlabel("horsepower")
#plt.pyplot.ylabel("count")
#plt.pyplot.title("horsepower bins")


bins = np.linspace(min(df["horsepower"]), max(df["horsepower"]), 4)
#print(bins)
group_names = ['Low', 'Medium', 'High']

df['horsepower-binned'] = pd.cut(df['horsepower'], bins, labels=group_names, include_lowest=True )
df[['horsepower','horsepower-binned']].head(20)

print(df["horsepower-binned"].value_counts())

################################## Lets plot the distribution of each bin. ############
pyplot.bar(group_names, df["horsepower-binned"].value_counts())

# set x/y labels and plot title
plt.pyplot.xlabel("horsepower")
plt.pyplot.ylabel("count")
plt.pyplot.title("horsepower bins")
