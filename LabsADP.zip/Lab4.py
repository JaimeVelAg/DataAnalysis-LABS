#Objectives
#In this section, we will develop several models that will predict the price of the car using the variables or features.
#This is just an estimate but should give us an objective idea of how much the car should cost.
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

#load data and store in dataframe df:
path = 'https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/IBMDeveloperSkillsNetwork-DA0101EN-SkillsNetwork/labs/Data%20files/automobileEDA.csv'
df = pd.read_csv(path)
df.head()

#                                   1. Linear Regression and Multiple Linear Regression
from sklearn.linear_model import LinearRegression
lm = LinearRegression()
lm

#How could Highway-mpg help us predict car price?
X = df[['highway-mpg']]
Y = df['price']
lm.fit(X,Y)
Yhat=lm.predict(X) #Yhat = price
Yhat[0:5]
lm.intercept_   #38423.3058581574               a
lm.coef_        #array([-821.73337832])         b   #slope - pendiente
#What is the final estimated linear model we get?
#𝑌ℎ𝑎𝑡=𝑎+𝑏𝑋    ------>     price = 38423.31 - 821.73 x highway-mpg
#Example: If we wanna predict the price for a car that has 26 highway-mpg
#price = 38423.31 - 821.73 * 26

#                                                       Multiple Linear Regression
#𝑌ℎ𝑎𝑡=𝑎+𝑏1𝑋1+𝑏2𝑋2+𝑏3𝑋3+𝑏4𝑋4
#From the previous section we know that other good predictors of price could be: Horsepower,Curb-weight,Engine-size,Highway-mpg
Z = df[['horsepower', 'curb-weight', 'engine-size', 'highway-mpg']]
lm.fit(Z, df['price'])
lm.intercept_       #-15806.62462632922
lm.coef_            #b1, b2, b3, b4 --> array([53.49574423,  4.70770099, 81.53026382, 36.05748882])
#What is the linear function we get in this example?
#Price = -15678.742628061467 + 52.65851272 x horsepower + 4.69878948 x curb-weight + 81.95906216 x engine-size + 33.58258185 x highway-mpg




#                                                      2) Model Evaluation using Visualization
import seaborn as sns
#                                                                   Regression Plot
#Let's visualize highway-mpg as potential predictor variable of price:
width = 12
height = 10
plt.figure(figsize=(width, height))
sns.regplot(x="highway-mpg", y="price", data=df)
plt.ylim(0,)
#plt.show()
## The variable "highway-mpg" has a stronger correlation with "price", it is approximate -0.704692
#compared to "peak-rpm" which is approximate -0.101616.
#You can verify it using the following command:
df[["peak-rpm","highway-mpg","price"]].corr()

#                                                                       Residual Plot
#A residual plot is a graph that shows the residuals on the vertical y-axis and the independent variable on the horizontal x-axis.
width = 12
height = 10
plt.figure(figsize=(width, height))
sns.residplot(df['highway-mpg'], df['price'])
#plt.show()
#                                                                   Multiple Linear Regression
Y_hat = lm.predict(Z)
plt.figure(figsize=(width, height))


ax1 = sns.distplot(df['price'], hist=False, color="r", label="Actual Value")
sns.distplot(Y_hat, hist=False, color="b", label="Fitted Values" , ax=ax1)


plt.title('Actual vs Fitted Values for Price')
plt.xlabel('Price (in dollars)')
plt.ylabel('Proportion of Cars')

#plt.show()
#plt.close()
#We can see that the fitted values are reasonably close to the actual values, since the two distributions overlap a bit.
#However, there is definitely some room for improvement.

#                                                             Part 3: Polynomial Regression and Pipelines
#Polynomial regression is a particular case of the general linear regression model or multiple linear regression models.
#Quadratic - 2nd order -->  𝑌ℎ𝑎𝑡=𝑎+𝑏1𝑋+𝑏2𝑋2
def PlotPolly(model, independent_variable, dependent_variabble, Name):
    x_new = np.linspace(15, 55, 100)
    y_new = model(x_new)

    plt.plot(independent_variable, dependent_variabble, '.', x_new, y_new, '-')
    plt.title('Polynomial Fit with Matplotlib for Price ~ Length')
    ax = plt.gca()
    ax.set_facecolor((0.898, 0.898, 0.898))
    fig = plt.gcf()
    plt.xlabel(Name)
    plt.ylabel('Price of Cars')

    plt.show()
    plt.close()

x = df['highway-mpg']
y = df['price']

# Here we use a polynomial of the 3rd order (cubic)
f = np.polyfit(x, y, 3)
p = np.poly1d(f)
#print(p)
#Let's plot the function
#PlotPolly(p, x, y, 'highway-mpg')
np.polyfit(x, y, 3)

#We can already see from plotting that this polynomial model performs better than the linear model.
#This is because the generated polynomial function "hits" more of the data points.

#Create 11 order polynomial model with the variables x and y from above
f1 = np.polyfit(x, y, 11)
p1 = np.poly1d(f1)
print(p1)
#PlotPolly(p1,x,y, 'Highway MPG')



#                                                                          Pipeline
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
#Input=[('scale',StandardScaler()), ('polynomial', PolynomialFeatures(include_bias=False)), ('model',LinearRegression())]
#pipe=Pipeline(Input)
#pipe
#We can normalize the data, perform a transform and fit the model simultaneously.
#pipe.fit(Z,y)



#                                                       Part 4: Measures for In-Sample Evaluation
#R^2 / R-squared
#Mean Squared Error (MSE)
#highway_mpg_fit
lm.fit(X, Y)
# Find the R^2
print('The R-square is: ', lm.score(X, Y))
#We can say that ~ 49.659% of the variation of the price is explained by this simple linear model "horsepower_fit".


#Let's calculate the MSE
from sklearn.metrics import mean_squared_error
mse = mean_squared_error(df['price'], Yhat)
print('The mean square error of price and predicted value is: ', mse)

#                                                              Model 2: Multiple Linear Regression
# fit the model
lm.fit(Z, df['price'])
# Find the R^2
print('The R-square is: ', lm.score(Z, df['price']))
Y_predict_multifit = lm.predict(Z)
print('The mean square error of price and predicted value using multifit is: ', \
      mean_squared_error(df['price'], Y_predict_multifit))


#                                                                  Model 3: Polynomial Fit
from sklearn.metrics import r2_score
r_squared = r2_score(y, p(x))
print('The R-square value is: ', r_squared)
#We can say that ~ 67.419 % of the variation of price is explained by this polynomial fit
#We can also calculate the MSE:
mean_squared_error(df['price'], p(x))
