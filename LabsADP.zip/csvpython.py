#source work/bin/activate
import pandas as pd #pip install pandas

#url donde se encuentra el .data
url = "/Users/jaimeisaivelazquezaguilar/Documents/DataAnalysis/imports-85.data"
#leer csv sin encabezados
df = pd.read_csv(url, header = None)
#encabezados
headers = ["symboling", "normalized-losses", "make", "fuel-type", "aspiration",
"num-of-doors", "body-style", "drive-wheels", "engine-location", "wheel-base",
"length", "width", "heigth", "curb-weight", "engine-type", "num-of-cylinders",
"engine-size", "fuel-system", "bore", "stroke", "compression-ratio", "horsepower",
"peak-rpm", "city-mpg", "highway-mpg", "price"]
#asignandolos al csv
df.columns=headers
#pintar las 5 primeras filas del csv
print(df.head(5))
#path de donde se guardara el csv con el nombre automobile.csv
path = "/Users/jaimeisaivelazquezaguilar/Documents/DataAnalysis/automobile.csv"
#convertir a csv 
df.to_csv(path)
