import pandas as pd
import numpy as np
other_path = "https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/IBMDeveloperSkillsNetwork-DA0101EN-SkillsNetwork/labs/Data%20files/auto.csv"
df = pd.read_csv(other_path, header=None)

headers = ["symboling","normalized-losses","make","fuel-type","aspiration", "num-of-doors","body-style",
         "drive-wheels","engine-location","wheel-base", "length","width","height","curb-weight","engine-type",
         "num-of-cylinders", "engine-size","fuel-system","bore","stroke","compression-ratio","horsepower",
         "peak-rpm","city-mpg","highway-mpg","price"]


# We replace headers and recheck our data frame
df.columns = headers

#we need to replace the "?" symbol with NaN so the dropna() can remove the missing values
df1=df.replace('?',np.NaN)

#we can drop missing values along the column "price" as follows
df=df1.dropna(subset=["price"], axis=0)

#Now, we have successfully read the raw dataset and add the correct headers into the data frame.
df.head(10)

#Find the name of the columns of the dataframe
#Index(['symboling', 'normalized-losses', 'make', 'fuel-type', 'aspiration', ...
print(df.columns)

#For example, if you would save the dataframe df as automobile.csv
#to your local machine, you may use the syntax below:
df.to_csv("automobile.csv", index=False)

# We can also read and save other file formats,
#we can use similar functions to **`pd.read_csv()`** and **`df.to_csv()`** for other
#data formats, the functions are listed in the following table:

#| Data Formate |        Read       |            Save |
#| ------------ | :---------------: | --------------: |
#| csv          |  `pd.read_csv()`  |   `df.to_csv()` |
#| json         |  `pd.read_json()` |  `df.to_json()` |
#| excel        | `pd.read_excel()` | `df.to_excel()` |
#| hdf          |  `pd.read_hdf()`  |   `df.to_hdf()` |
#| sql          |  `pd.read_sql()`  |   `df.to_sql()` |
#| ...          |        ...        |             ... |

# check the data type of data frame "df" by .dtypes
#symboling              int64
#normalized-losses     object
#...
print(df.dtypes)

#This method will provide various summary statistics, excluding NaN (Not a Number) values.
df.describe()

# describe all the columns in "df"
df.describe(include = "all")

#You can select the columns of a data frame by indicating the name of  each column,
#for example, you can select the three columns as follows:
df[['length', 'compression-ratio']].describe()


#It provide a concise summary of your DataFrame.
df.info()
